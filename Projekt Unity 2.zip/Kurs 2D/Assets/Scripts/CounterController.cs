using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro; // Import TextMeshPro namespace

public class CounterController : MonoBehaviour
{
    int numberOfBoxes;
    public TMP_Text counterView; // Zmieniamy typ na TMP_Text

    // Start is called before the first frame update
    void Start()
    {
        if (counterView == null)
        {
            Debug.LogError("counterView nie jest przypisany w inspektorze.");
            return;
        }
        ResetCounter();
    }

    public void IncrementCounter()
    {
        numberOfBoxes ++;
        counterView.text = numberOfBoxes.ToString();
    }

    public void ResetCounter()
    {
        numberOfBoxes = 0;
        counterView.text = numberOfBoxes.ToString();
    }
}